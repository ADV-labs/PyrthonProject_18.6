TOKEN = '5186625574:AAFKOzRndl8zqhsl90bgbDQSXV_QHNm0wx4'

keys = {
    'биткоин': 'BTC',
    'эфириум' : 'ETH',
    'доллар': 'USD',
}